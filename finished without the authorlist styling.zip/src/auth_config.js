// auth_config.js
export const authConfig = {
    domain: "dev-j0zlk7gogm1b2ben.us.auth0.com",
    clientId: "ffe47fxGRhuze07vSOfbagpinW4Hnz0w",
    redirectUri: window.location.origin, // This will be http://localhost:3000
    audience: "http://localhost:3001",
  };
  