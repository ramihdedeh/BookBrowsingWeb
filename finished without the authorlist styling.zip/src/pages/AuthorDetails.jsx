import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import axios from "axios";
import { Container, Typography, Card, CardMedia, CardContent, CircularProgress, Grid, Box } from "@mui/material";

const AuthorDetails = () => {
  const { id } = useParams();
  const [author, setAuthor] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchAuthorDetails();
  }, []);

  const fetchAuthorDetails = async () => {
    try {
      const response = await axios.get(`https://openlibrary.org/authors/${id}.json`);
      setAuthor(response.data);
      setLoading(false);
    } catch (error) {
      console.error("Error fetching author details:", error);
      setLoading(false);
    }
  };

  if (loading) {
    return <CircularProgress sx={{ display: "block", margin: "50px auto" }} />;
  }

  return (
    <Container maxWidth="md" sx={{ marginTop: 4 }}>
      <Card sx={{ padding: 3, borderRadius: 3, boxShadow: 3 }}>
        <Grid container spacing={3} alignItems="center">
          {/* Left Side - Author Image */}
          <Grid item xs={12} md={4}>
            {author.photos ? (
              <CardMedia
                component="img"
                sx={{ width: "100%", height: "auto", borderRadius: 2 }}
                image={`https://covers.openlibrary.org/b/id/${author.photos[0]}-L.jpg`}
                alt={author.name}
              />
            ) : (
              <Typography variant="h6" sx={{ textAlign: "center", padding: "20px" }}>
                No Image Available
              </Typography>
            )}
          </Grid>

          {/* Right Side - Author Details */}
          <Grid item xs={12} md={8}>
            <Box>
              {/* Author Name */}
              <Typography variant="h4" fontWeight="bold" sx={{ marginBottom: 2 }}>
                {author.name || "Unknown Author"}
              </Typography>

              {/* Author Biography */}
              <Typography variant="body1" sx={{ marginBottom: 2, color: "gray" }}>
                {author.bio
                  ? typeof author.bio === "string"
                    ? author.bio
                    : author.bio.value
                  : "No biography available"}
              </Typography>

              {/* Birth Date */}
              <Typography variant="h6" sx={{ marginBottom: 1, fontWeight: "medium" }}>
                🎂 Birth Date: {author.birth_date || "Unknown"}
              </Typography>

              {/* Death Date */}
              <Typography variant="h6" sx={{ marginBottom: 1, fontWeight: "medium" }}>
                🕊 Death Date: {author.death_date || "N/A"}
              </Typography>
            </Box>
          </Grid>
        </Grid>
      </Card>
    </Container>
  );
};

export default AuthorDetails;
